/**
 * Script para controlar el carrusel de servicios en la página principal.
 * Maneja navegación con botones prev/next, dots indicadores y autoplay infinito.
 * Se ejecuta cuando el DOM está listo.
 */

document.addEventListener("DOMContentLoaded", () => {
    // Logs de depuración (remover en producción)
    console.log("Carousel script loaded");
    const carousel = document.querySelector(".carousel");
    if (!carousel) {
        console.error("Carousel element not found");
        return;
    }
    console.log("Carousel found");

    // Seleccionar elementos del carrusel
    const track = carousel.querySelector(".carousel-track");
    const slides = Array.from(carousel.querySelectorAll(".carousel-slide"));
    const prevBtn = carousel.querySelector(".carousel-btn.prev");
    const nextBtn = carousel.querySelector(".carousel-btn.next");
    const dotsContainer = carousel.querySelector(".carousel-dots");

    console.log("Slides found:", slides.length);
    console.log("Prev btn:", prevBtn);
    console.log("Next btn:", nextBtn);
    console.log("Dots container:", dotsContainer);

    // Duplicar slides para efecto infinito seamless
    slides.forEach(slide => {
        const clone = slide.cloneNode(true);
        track.appendChild(clone);
    });

    const allSlides = Array.from(track.querySelectorAll(".carousel-slide"));
    const totalSlides = allSlides.length;
    const originalCount = slides.length;

    let currentIndex = 0;
    let autoplayInterval = null;
    const AUTOPLAY_DELAY = 4000; // 4 segundos

    // Inicializar en el primer slide original
    track.style.transition = "none";
    track.style.transform = `translateX(0%)`;
    currentIndex = 0;

    /**
     * Mueve el carrusel a un índice específico.
     * @param {number} index - Índice del slide a mostrar.
     */
    function goToSlide(index) {
        currentIndex = index;
        track.style.transition = "transform 0.35s ease";
        track.style.transform = `translateX(-${currentIndex * 100}%)`;

        // Actualizar dots activos (solo los originales)
        const dots = Array.from(dotsContainer.children);
        dots.forEach((dot, i) => {
            dot.classList.toggle("active", i === currentIndex % originalCount);
        });
    }

    /**
     * Inicia el movimiento automático del carrusel.
     */
    function startAutoplay() {
        autoplayInterval = setInterval(() => {
            currentIndex++;
            goToSlide(currentIndex);

            // Cuando llegamos al final de los slides duplicados, reiniciamos sin transición
            if (currentIndex >= originalCount) {
                setTimeout(() => {
                    track.style.transition = "none";
                    currentIndex = 0;
                    track.style.transform = `translateX(0%)`;
                }, 350);
            }
        }, AUTOPLAY_DELAY);
    }

    /**
     * Detiene y reinicia el autoplay.
     */
    function resetAutoplay() {
        clearInterval(autoplayInterval);
        startAutoplay();
    }

    // Crear dots para cada slide original
    slides.forEach((_, index) => {
        const dot = document.createElement("button");
        dot.type = "button";
        dot.setAttribute("aria-label", `Ir al servicio ${index + 1}`);
        dot.addEventListener("click", () => {
            console.log("Dot clicked:", index);
            goToSlide(index);
            resetAutoplay();
        });
        dotsContainer.appendChild(dot);
    });

    // Event listeners para botones prev/next
    if (prevBtn) prevBtn.addEventListener("click", () => {
        console.log("Prev button clicked");
        currentIndex--;
        goToSlide(currentIndex);
        
        // Si llegamos antes del primer slide, saltamos al final sin transición
        if (currentIndex < 0) {
            setTimeout(() => {
                track.style.transition = "none";
                currentIndex = originalCount - 1;
                track.style.transform = `translateX(-${currentIndex * 100}%)`;
            }, 350);
        }
        resetAutoplay();
    });
    
    if (nextBtn) nextBtn.addEventListener("click", () => {
        console.log("Next button clicked");
        currentIndex++;
        goToSlide(currentIndex);
        
        // Si llegamos al final de los slides originales, saltamos al inicio sin transición
        if (currentIndex >= originalCount) {
            setTimeout(() => {
                track.style.transition = "none";
                currentIndex = 0;
                track.style.transform = `translateX(0%)`;
            }, 350);
        }
        resetAutoplay();
    });

    // Pausar autoplay al hacer hover y reanudar al salir
    carousel.addEventListener("mouseenter", () => clearInterval(autoplayInterval));
    carousel.addEventListener("mouseleave", () => startAutoplay());

    console.log("Carousel initialized");
    // Inicializar primer dot como activo
    if (dotsContainer.children.length > 0) {
        dotsContainer.children[0].classList.add("active");
    }
    startAutoplay();
});
